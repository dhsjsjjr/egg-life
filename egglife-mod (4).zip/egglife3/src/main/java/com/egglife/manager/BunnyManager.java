package com.egglife.manager;

import com.egglife.entity.PlayerBunnyEntity;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameMode;
import net.minecraft.world.Heightmap;
import java.util.*;

public class BunnyManager {
    private static final Map<UUID, UUID> playerToBunny = new HashMap<>();
    private static final Map<UUID, UUID> bunnyToPlayer = new HashMap<>();

    public static void register() {
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof PlayerBunnyEntity bunny) {
                UUID ownerUUID = bunnyToPlayer.get(bunny.getUuid());
                if (ownerUUID != null && bunny.getServer() != null) {
                    ServerPlayerEntity player = bunny.getServer().getPlayerManager().getPlayer(ownerUUID);
                    if (player != null) player.damage(source, amount);
                }
            }
            return true;
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof PlayerBunnyEntity bunny) {
                UUID ownerUUID = bunnyToPlayer.remove(bunny.getUuid());
                if (ownerUUID != null && bunny.getServer() != null) {
                    playerToBunny.remove(ownerUUID);
                    ServerPlayerEntity player = bunny.getServer().getPlayerManager().getPlayer(ownerUUID);
                    if (player != null) {
                        bunny.getServer().getPlayerManager().broadcast(
                            Text.literal(player.getName().getString() + "'s bunny died! They lose a life!").formatted(Formatting.RED), false);
                        triggerLifeLoss(player);
                    }
                }
            }
            if (entity instanceof ServerPlayerEntity player) {
                UUID bunnyUUID = playerToBunny.remove(player.getUuid());
                if (bunnyUUID != null) {
                    ServerWorld world = player.getServer().getOverworld();
                    world.getEntitiesByClass(PlayerBunnyEntity.class, player.getBoundingBox().expand(2000),
                        b -> b.getUuid().equals(bunnyUUID)).forEach(b -> {
                            spawnParticles(world, b.getX(), b.getY(), b.getZ());
                            b.kill();
                        });
                    bunnyToPlayer.remove(bunnyUUID);
                }
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 != 0) return;
            ServerWorld world = server.getOverworld();
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                if (playerToBunny.containsKey(player.getUuid())) continue;
                world.getEntitiesByClass(PlayerBunnyEntity.class, player.getBoundingBox().expand(6),
                    b -> b.getOwnerName().equals(player.getName().getString()) && !b.isBunnyTamed()
                ).stream().findFirst().ifPresent(bunny -> {
                    bunny.setBunnyTamed(true);
                    bunny.setCustomName(Text.literal(player.getName().getString() + "'s Bunny").formatted(Formatting.AQUA));
                    bunny.setCustomNameVisible(true);
                    playerToBunny.put(player.getUuid(), bunny.getUuid());
                    bunnyToPlayer.put(bunny.getUuid(), player.getUuid());
                    player.sendMessage(Text.literal("You found your bunny! Protect it with your life!").formatted(Formatting.GREEN), false);
                });
            }
        });
    }

    public static void spawnBunny(ServerPlayerEntity player, ServerWorld world) {
        Random rand = new Random();
        int x = rand.nextInt(480) - 240;
        int z = rand.nextInt(480) - 240;
        int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        PlayerBunnyEntity bunny = new PlayerBunnyEntity(PlayerBunnyEntity.TYPE, world);
        bunny.refreshPositionAndAngles(x, y, z, 0, 0);
        bunny.setOwnerName(player.getName().getString());
        world.spawnEntity(bunny);
        player.sendMessage(Text.literal("Your bunny is somewhere out there... go find it!").formatted(Formatting.GOLD), false);
    }

    public static void triggerLifeLoss(ServerPlayerEntity player) {
        MinecraftServer server = player.getServer();
        LifeManager lm = LifeManager.get(server);
        int current = lm.getLives(player.getUuid());
        if (current <= 0) return;
        int newLives = current - 1;
        lm.setLives(player.getUuid(), newLives);
        if (newLives <= 0) permanentDeath(player, server);
        else {
            
            player.sendMessage(Text.literal("You lost a life! " + newLives + " left.").formatted(Formatting.RED), false);
        }
    }

    private static void permanentDeath(ServerPlayerEntity player, MinecraftServer server) {
        ServerWorld world = server.getOverworld();
        double x = player.getX(), y = player.getY(), z = player.getZ();
        spawnParticles(world, x, y, z);
        world.playSound(null, BlockPos.ofFloored(x, y, z), SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.MASTER, 1f, 1f);
        LightningEntity bolt = new LightningEntity(EntityType.LIGHTNING_BOLT, world);
        bolt.refreshPositionAndAngles(x, y, z, 0, 0);
        bolt.setCosmetic(true);
        world.spawnEntity(bolt);
        server.getPlayerManager().getPlayerList().forEach(p -> {
            p.networkHandler.sendPacket(new TitleS2CPacket(
                Text.literal(player.getName().getString() + " HAS FALLEN").formatted(Formatting.DARK_RED, Formatting.BOLD)));
            p.networkHandler.sendPacket(new SubtitleS2CPacket(
                Text.literal("Their story is over.").formatted(Formatting.RED)));
        });
        server.getPlayerManager().broadcast(
            Text.literal("☠ " + player.getName().getString() + " has lost all their lives.").formatted(Formatting.DARK_RED), false);
        player.changeGameMode(GameMode.SPECTATOR);
    }

    public static void spawnParticles(ServerWorld world, double x, double y, double z) {
        world.spawnParticles(ParticleTypes.LARGE_SMOKE, x, y + 1, z, 50, 0.5, 0.5, 0.5, 0.1);
        world.spawnParticles(ParticleTypes.ASH, x, y + 1, z, 80, 1.0, 1.0, 1.0, 0.1);
    }
}
