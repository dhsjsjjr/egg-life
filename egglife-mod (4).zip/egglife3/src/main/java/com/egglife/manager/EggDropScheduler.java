package com.egglife.manager;

import com.egglife.config.EggLifeConfig;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;
import java.util.*;

public class EggDropScheduler {
    private static final Random rand = new Random();
    private static int ticksUntilDrop = -1;
    private static boolean active = false;

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!active) return;
            if (ticksUntilDrop < 0) ticksUntilDrop = nextInterval();
            ticksUntilDrop--;
            if (ticksUntilDrop <= 0) {
                drop(server);
                ticksUntilDrop = nextInterval();
            }
        });
    }

    private static void drop(MinecraftServer server) {
        ServerWorld world = server.getOverworld();
        EggLifeConfig cfg = EggLifeConfig.get();
        int count = cfg.egg_drop_min_count + rand.nextInt(Math.max(1, cfg.egg_drop_max_count - cfg.egg_drop_min_count));

        server.getPlayerManager().broadcast(
            Text.literal("🐣 The Easter Bunny has visited! Eggs are hidden across the world!").formatted(Formatting.LIGHT_PURPLE), false);

        for (int i = 0; i < count; i++) {
            int x = rand.nextInt(480) - 240;
            int z = rand.nextInt(480) - 240;
            int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
            ItemStack egg = randomEgg();
            ItemEntity entity = new ItemEntity(world, x, y, z, egg);
            entity.setPickupDelay(0);
            world.spawnEntity(entity);
        }
    }

    private static ItemStack randomEgg() {
        // 60% chocolate egg (common), 40% dyed egg (rarer/better)
        boolean useDyed = rand.nextInt(100) < 40;
        String id = useDyed ? "eastersdelight:dyed_egg" : "eastersdelight:chocolate_egg";
        Item item = Registries.ITEM.get(new Identifier(id));
        // Fallback to vanilla egg if Easter's Delight not installed
        if (item == Items.AIR) item = Items.EGG;
        return new ItemStack(item);
    }

    private static int nextInterval() {
        EggLifeConfig cfg = EggLifeConfig.get();
        int minTicks = cfg.egg_drop_min_minutes * 60 * 20;
        int maxTicks = cfg.egg_drop_max_minutes * 60 * 20;
        return minTicks + rand.nextInt(Math.max(1, maxTicks - minTicks));
    }

    public static void setActive(boolean val) {
        active = val;
        if (val) ticksUntilDrop = nextInterval();
    }
}
