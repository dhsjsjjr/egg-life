package com.egglife.manager;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateManager;
import java.util.*;

public class LifeManager extends PersistentState {
    private final Map<UUID, Integer> lives = new HashMap<>();
    private static final String KEY = "egglife_lives";

    public static LifeManager get(MinecraftServer server) {
        PersistentStateManager mgr = server.getOverworld().getPersistentStateManager();
        return mgr.getOrCreate(
            new PersistentState.Type<>(LifeManager::new, LifeManager::fromNbt, null),
            KEY
        );
    }

    public static LifeManager fromNbt(NbtCompound nbt) {
        LifeManager m = new LifeManager();
        NbtCompound l = nbt.getCompound("lives");
        for (String k : l.getKeys()) m.lives.put(UUID.fromString(k), l.getInt(k));
        return m;
    }

    public int getLives(UUID uuid) { return lives.getOrDefault(uuid, -1); }
    public void setLives(UUID uuid, int count) { lives.put(uuid, count); markDirty(); }
    public void addLife(UUID uuid) { int c = getLives(uuid); if (c < 3) setLives(uuid, c + 1); }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtCompound l = new NbtCompound();
        lives.forEach((uuid, count) -> l.putInt(uuid.toString(), count));
        nbt.put("lives", l);
        return nbt;
    }
}
