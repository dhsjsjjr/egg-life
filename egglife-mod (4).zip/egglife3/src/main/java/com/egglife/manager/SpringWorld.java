package com.egglife.manager;

import com.egglife.item.BasketItem;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import java.util.Random;

public class SpringWorld {
    private static final Random rand = new Random();
    private static int weatherTick = 0;
    private static int flowerTick = 0;
    private static int particleTick = 0;
    private static boolean active = false;

    private static final BlockState[] FLOWERS = {
        Blocks.DANDELION.getDefaultState(), Blocks.POPPY.getDefaultState(),
        Blocks.BLUE_ORCHID.getDefaultState(), Blocks.ALLIUM.getDefaultState(),
        Blocks.AZURE_BLUET.getDefaultState(), Blocks.OXEYE_DAISY.getDefaultState(),
        Blocks.CORNFLOWER.getDefaultState(), Blocks.LILY_OF_THE_VALLEY.getDefaultState()
    };

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!active) return;
            ServerWorld world = server.getOverworld();

            if (++weatherTick >= 200) {
                weatherTick = 0;
                if (world.isThundering()) world.setWeather(0, 6000, true, false);
            }

            if (++flowerTick >= 6000) {
                flowerTick = 0;
                for (int i = 0; i < 10; i++) {
                    int x = rand.nextInt(480) - 240;
                    int z = rand.nextInt(480) - 240;
                    int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
                    BlockPos pos = new BlockPos(x, y, z);
                    if (world.getBlockState(pos).isAir() && world.getBlockState(pos.down()).isOf(Blocks.GRASS_BLOCK)) {
                        world.setBlockState(pos, FLOWERS[rand.nextInt(FLOWERS.length)]);
                    }
                }
            }

            if (++particleTick >= 100) {
                particleTick = 0;
                world.getPlayers().forEach(p ->
                    world.spawnParticles(ParticleTypes.CHERRY_LEAVES,
                        p.getX() + (rand.nextDouble() - 0.5) * 6, p.getY() + 3,
                        p.getZ() + (rand.nextDouble() - 0.5) * 6, 3, 0.5, 0.5, 0.5, 0.02));
            }

            BasketItem.tick(world);
        });
    }

    public static void setActive(boolean val) { active = val; }
}
