package com.egglife;

import com.egglife.client.renderer.PlayerBunnyRenderer;
import com.egglife.entity.PlayerBunnyEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class EggLifeClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(PlayerBunnyEntity.TYPE, PlayerBunnyRenderer::new);
    }
}
