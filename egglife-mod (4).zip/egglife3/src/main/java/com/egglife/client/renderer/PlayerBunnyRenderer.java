package com.egglife.client.renderer;

import com.egglife.EggLifeMod;
import com.egglife.entity.PlayerBunnyEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.RabbitEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.util.Identifier;

public class PlayerBunnyRenderer extends MobEntityRenderer<PlayerBunnyEntity, RabbitEntityModel<PlayerBunnyEntity>> {

    // Fallback texture if no custom PNG found
    private static final Identifier FALLBACK = new Identifier("textures/entity/rabbit/brown.png");

    public PlayerBunnyRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new RabbitEntityModel<>(ctx.getPart(EntityModelLayers.RABBIT)), 0.3f);
    }

    @Override
    public Identifier getTexture(PlayerBunnyEntity entity) {
        String ownerName = entity.getOwnerName();
        if (ownerName != null && !ownerName.isEmpty()) {
            // Looks for assets/egglife/textures/bunny/<PlayerName>.png
            Identifier custom = new Identifier(EggLifeMod.MOD_ID, "textures/bunny/" + ownerName + ".png");
            // Check if resource exists, fall back to default if not
            try {
                net.minecraft.client.MinecraftClient client = net.minecraft.client.MinecraftClient.getInstance();
                if (client.getResourceManager().getResource(custom).isPresent()) {
                    return custom;
                }
            } catch (Exception ignored) {}
        }
        return FALLBACK;
    }
}
