package com.egglife.item;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.item.Item;
import net.minecraft.util.Identifier;

public class EggLifeItems {
    public static final Item EASTER_BASKET = new BasketItem(new FabricItemSettings().maxCount(1).maxDamage(100));

    public static void register() {
        Registry.register(Registries.ITEM, new Identifier("egglife", "easter_basket"), EASTER_BASKET);
    }
}
