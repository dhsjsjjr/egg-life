package com.egglife.item;

import com.egglife.entity.PlayerBunnyEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import java.util.*;

public class BasketItem extends Item {
    private static final Map<UUID, Long> cooldowns = new HashMap<>();
    private static final Map<UUID, Long> hideEnd = new HashMap<>();
    private static final long COOLDOWN = 5 * 60 * 1000L;
    private static final long DURATION = 60 * 1000L;

    public BasketItem(Settings s) { super(s); }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        if (world.isClient) return TypedActionResult.pass(user.getStackInHand(hand));
        ServerPlayerEntity player = (ServerPlayerEntity) user;
        ItemStack stack = player.getStackInHand(hand);
        UUID uuid = player.getUuid();
        long now = System.currentTimeMillis();

        if (cooldowns.containsKey(uuid) && now - cooldowns.get(uuid) < COOLDOWN) {
            long remaining = (COOLDOWN - (now - cooldowns.get(uuid))) / 1000;
            player.sendMessage(Text.literal("Basket cooldown: " + remaining + "s").formatted(Formatting.YELLOW), true);
            return TypedActionResult.fail(stack);
        }

        ServerWorld sw = (ServerWorld) world;
        Optional<PlayerBunnyEntity> bunny = sw.getEntitiesByClass(PlayerBunnyEntity.class,
            player.getBoundingBox().expand(2000),
            b -> b.getOwnerName().equals(player.getName().getString())).stream().findFirst();

        if (bunny.isEmpty()) {
            player.sendMessage(Text.literal("Your bunny isn't nearby!").formatted(Formatting.RED), true);
            return TypedActionResult.fail(stack);
        }

        bunny.get().setInvisible(true);
        bunny.get().setAiDisabled(true);
        bunny.get().addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 1200, 0, false, false));
        cooldowns.put(uuid, now);
        hideEnd.put(uuid, now + DURATION);
        stack.damage(10, player, p -> p.sendToolBreakStatus(hand));
        player.sendMessage(Text.literal("Bunny hidden for 60s!").formatted(Formatting.GREEN), true);
        return TypedActionResult.success(stack);
    }

    public static void tick(ServerWorld world) {
        long now = System.currentTimeMillis();
        hideEnd.entrySet().removeIf(e -> {
            if (now >= e.getValue()) {
                ServerPlayerEntity p = world.getServer().getPlayerManager().getPlayer(e.getKey());
                if (p != null) {
                    world.getEntitiesByClass(PlayerBunnyEntity.class, p.getBoundingBox().expand(2000),
                        b -> b.getOwnerName().equals(p.getName().getString())).forEach(b -> {
                            b.setInvisible(false);
                            b.setAiDisabled(false);
                        });
                    p.sendMessage(Text.literal("Your bunny is visible again!").formatted(Formatting.AQUA), true);
                }
                return true;
            }
            return false;
        });
    }
}
