package com.egglife.entity;

import com.egglife.EggLifeMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.passive.RabbitEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

public class PlayerBunnyEntity extends RabbitEntity {

    public static EntityType<PlayerBunnyEntity> TYPE;

    private String ownerName = "";
    private boolean tamed = false;

    public PlayerBunnyEntity(EntityType<? extends RabbitEntity> type, World world) {
        super(type, world);
    }

    public String getOwnerName() { return ownerName; }
    public void setOwnerName(String name) { this.ownerName = name; }
    public boolean isBunnyTamed() { return tamed; }
    public void setBunnyTamed(boolean val) { this.tamed = val; }

    public void disableAi(boolean disable) { this.setAiDisabled(disable); }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putString("EggLifeOwner", ownerName);
        nbt.putBoolean("EggLifeTamed", tamed);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.contains("EggLifeOwner")) ownerName = nbt.getString("EggLifeOwner");
        if (nbt.contains("EggLifeTamed")) tamed = nbt.getBoolean("EggLifeTamed");
    }

    public static void register() {
        TYPE = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(EggLifeMod.MOD_ID, "player_bunny"),
            FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, PlayerBunnyEntity::new)
                .dimensions(EntityDimensions.fixed(0.4f, 0.5f))
                .build()
        );
    }
}
