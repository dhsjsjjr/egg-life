package com.egglife.command;

import com.egglife.manager.BunnyManager;
import com.egglife.manager.EggDropScheduler;
import com.egglife.manager.LifeManager;
import com.egglife.manager.SpringWorld;
import com.egglife.item.EggLifeItems;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.border.WorldBorder;

public class EggLifeCommand {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(CommandManager.literal("egglife")
                .requires(src -> src.hasPermissionLevel(2))

                .then(CommandManager.literal("start").executes(ctx -> {
                    MinecraftServer server = ctx.getSource().getServer();
                    ServerWorld world = server.getOverworld();
                    LifeManager lm = LifeManager.get(server);
                    

                    WorldBorder border = world.getWorldBorder();
                    border.setCenter(0, 0);
                    border.setSize(500);

                    for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                        lm.setLives(p.getUuid(), 3);
                        LifeManager.updateTeam(p, 3);
                        ItemStack basket = EggLifeItems.EASTER_BASKET.getDefaultStack();
                        if (!p.getInventory().insertStack(basket)) p.dropItem(basket, false);
                        BunnyManager.spawnBunny(p, world);
                    }

                    EggDropScheduler.setActive(true);
                    SpringWorld.setActive(true);

                    server.getPlayerManager().broadcast(
                        Text.literal("🐣 Egg Life has begun! Find your bunny!").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD), false);
                    return 1;
                }))

                .then(CommandManager.literal("lives")
                    .then(CommandManager.argument("player", EntityArgumentType.player()).executes(ctx -> {
                        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
                        int lives = LifeManager.get(ctx.getSource().getServer()).getLives(target.getUuid());
                        ctx.getSource().sendFeedback(() ->
                            Text.literal(target.getName().getString() + " has " + lives + " life/lives.").formatted(Formatting.YELLOW), false);
                        return lives;
                    })))

                .then(CommandManager.literal("revive")
                    .then(CommandManager.argument("player", EntityArgumentType.player()).executes(ctx -> {
                        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
                        MinecraftServer server = ctx.getSource().getServer();
                        LifeManager lm = LifeManager.get(server);
                        lm.addLife(target.getUuid());
                        
                        ctx.getSource().sendFeedback(() ->
                            Text.literal("Revived " + target.getName().getString()).formatted(Formatting.GREEN), true);
                        return 1;
                    })))

                .then(CommandManager.literal("stop").executes(ctx -> {
                    EggDropScheduler.setActive(false);
                    SpringWorld.setActive(false);
                    LifeManager.get(ctx.getSource().getServer()).markDirty();
                    ctx.getSource().sendFeedback(() -> Text.literal("Egg Life stopped.").formatted(Formatting.YELLOW), true);
                    return 1;
                }))
            )
        );
    }
}
