package com.egglife.mixin;

import com.egglife.manager.LifeManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ServerPlayerEntity.class)
public class PlayerNameMixin {
    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void colorByLives(CallbackInfoReturnable<Text> cir) {
        ServerPlayerEntity player = (ServerPlayerEntity)(Object)this;
        if (player.getServer() == null) return;
        int lives = LifeManager.get(player.getServer()).getLives(player.getUuid());
        if (lives < 0) return;
        Formatting color = lives >= 3 ? Formatting.GREEN : lives == 2 ? Formatting.YELLOW : Formatting.RED;
        cir.setReturnValue(Text.literal(player.getName().getString()).formatted(color));
    }
}
