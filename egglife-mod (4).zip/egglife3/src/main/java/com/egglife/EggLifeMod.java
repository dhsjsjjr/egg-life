package com.egglife;

import com.egglife.command.EggLifeCommand;
import com.egglife.config.EggLifeConfig;
import com.egglife.entity.PlayerBunnyEntity;
import com.egglife.item.EggLifeItems;
import com.egglife.manager.BunnyManager;
import com.egglife.manager.EggDropScheduler;
import com.egglife.manager.SpringWorld;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EggLifeMod implements ModInitializer {
    public static final String MOD_ID = "egglife";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        EggLifeConfig.load();
        PlayerBunnyEntity.register();
        EggLifeItems.register();
        EggLifeCommand.register();
        BunnyManager.register();
        EggDropScheduler.register();
        SpringWorld.register();
        LOGGER.info("Egg Life initialized!");
    }
}
