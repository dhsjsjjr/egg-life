package com.egglife.config;

import com.egglife.EggLifeMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.nio.file.Path;

public class EggLifeConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static EggLifeConfig INSTANCE = new EggLifeConfig();

    public int egg_drop_min_minutes = 15;
    public int egg_drop_max_minutes = 30;
    public int egg_drop_min_count = 30;
    public int egg_drop_max_count = 50;

    public static EggLifeConfig get() { return INSTANCE; }

    public static void load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("egglife.json");
        File file = path.toFile();
        if (file.exists()) {
            try (Reader r = new FileReader(file)) {
                INSTANCE = GSON.fromJson(r, EggLifeConfig.class);
            } catch (Exception e) {
                EggLifeMod.LOGGER.error("Failed to load config, using defaults.", e);
            }
        } else {
            save();
        }
    }

    public static void save() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("egglife.json");
        try (Writer w = new FileWriter(path.toFile())) {
            GSON.toJson(INSTANCE, w);
        } catch (Exception e) {
            EggLifeMod.LOGGER.error("Failed to save config.", e);
        }
    }
}
