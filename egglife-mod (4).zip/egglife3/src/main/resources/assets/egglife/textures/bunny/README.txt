HOW TO ADD CUSTOM BUNNY SKINS
==============================
Place PNG files named after each player in this folder.
Example: Steve.png, Aubrey.png, Alex.png

The file name must match the player's exact Minecraft username (case-sensitive).
The PNG should be a valid rabbit skin texture (same layout as vanilla rabbit skins).
If no file is found for a player, their bunny will use the default brown vanilla texture.
